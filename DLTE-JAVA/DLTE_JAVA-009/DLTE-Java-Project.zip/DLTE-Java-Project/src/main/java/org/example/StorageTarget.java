package org.example;

public interface StorageTarget {
    UserFileRepository getUserFileRepository();
}
